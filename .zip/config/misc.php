<?php

return [
	/**
	 * In seconds
	 * Default: 10 mins
	 */
	'session_timeout_status' => env('SESSION_TIMEOUT_STATUS', true),
	'session_timeout' => env('SESSION_TIMEOUT', 600)
];