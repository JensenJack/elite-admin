<?php

return [

	/**
	 * The view that controls how the breadcrumbs are displayed
	 */
    'view' => 'backend.includes.partials.breadcrumbs',

];
