<?php

namespace App\Events;

/**
 * Class Event
 * @package App\Events
 */
abstract class Event
{
    //
}
