composer install
npm install
Create .env file (.env.example included)
php artisan key:generate
php artisan migrate
Set administrator info in UserTableSeeder.php
php artisan db:seed
run gulp or gulp watch (Install gulp (sudo npm install -g gulp) if needed)
Optional: View Suggested Packages