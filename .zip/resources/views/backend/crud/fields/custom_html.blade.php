<!-- used for heading, separators, etc -->
<div @include('crud::inc.field_wrapper_attributes') >
	{!! $field['value'] !!}
</div>