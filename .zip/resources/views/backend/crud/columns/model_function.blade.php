{{-- custom return value --}}
<td>
	<?php
	    echo $entry->{$column['function_name']}();
    ?>
</td>