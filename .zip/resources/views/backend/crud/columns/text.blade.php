{{-- regular object attribute --}}
<td>{{ str_limit(strip_tags($entry->{$column['name']}), 80, "[...]") }}</td>