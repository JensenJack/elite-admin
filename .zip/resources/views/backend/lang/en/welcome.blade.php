<div style="margin-left:50px;">
<img src="https://www.tinymce.com/images/glyph-tinymce@2x.png" alt="TinyMCE" width="110" height="97" />
<p>Elite-Admin is a platform independent web-based <br /> editor control.</p>

<li>rotas gerando os json </li>
<li>gerar o starter do projeto e colocar no packgist e github</li>
<li>arquivos readme</li>
<li>erro no datatable dos users</li>
<li>token nao segura direito o login em algumas atividades</li>
<li>limpar a pasta public, assets, pacote elfinder</li>
<li>crud search e delete</li>
<li>alerts e javascript files dentro dos blades </li>
<li>gerar um controler dinamica para as paginas criados por crud</li>
<li>criar o modelo de templates pra usar os widgets</li>
<li>criar o modelo de templates pra usar os widgets</li>
<li>pacotes de tag, langs,</li>
</div>